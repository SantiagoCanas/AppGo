package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EditarU extends AppCompatActivity {

    Button Editar, Buscar, Atras;
    RequestQueue requestQueue;
    EditText EditPassword, EditTelefono;
    TextView EditNombre, EditGenero, EditFacultad, EditCorreo, EditRol, truco;
    Spinner spinnerm, spinneres, spinnertu;
    String selectuser, State, Idest, Tu, Idtu;
    private ArrayList<Usuarios> crackuser;
    private ArrayList<Usuarios> cracktu;
    private ArrayList<Usuarios> crackest;
    @Override
    //onCreate: Este metodo se caracteriza por definir las variables para editar un usuario o gestor.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.editarusuario);
        spinnerm = (Spinner) findViewById(R.id.spinnerM);
        spinneres = (Spinner) findViewById(R.id.spinnerEs);
        spinnertu = (Spinner) findViewById(R.id.spinnerTu2);
        EditNombre = (TextView) findViewById(R.id.TextNombre2);
        EditTelefono = (EditText) findViewById(R.id.TextTelefono2);
        EditFacultad = (TextView) findViewById(R.id.TextFacultad2);
        EditGenero = (TextView) findViewById(R.id.TextGenero2);
        EditCorreo = (TextView) findViewById(R.id.TextCorreo2);
        EditPassword = (EditText) findViewById(R.id.TextPassword2);
        EditRol = (TextView) findViewById(R.id.TextRol2);
        truco = (TextView) findViewById(R.id.textEditarUser4);
        Buscar = findViewById(R.id.ButtonBuscarEd);
        cancelar();
        spinneres.setVisibility(View.INVISIBLE);

        new EditarU.GetEst().execute();
        crackest = new ArrayList<Usuarios>();
        spinneres.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                cracktu.clear();
                crackest.clear();
                crackuser.clear();
                State = spinneres.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_est.php?Estado="+State+"";

                temp = temp.replaceAll(" ", "%20");
                buscar2(temp);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        new EditarU.GetTu().execute();
        cracktu = new ArrayList<Usuarios>();
        spinnertu.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                cracktu.clear();
                crackest.clear();
                crackuser.clear();
                Tu = spinnertu.getItemAtPosition(position).toString();
                limpiar();
                String temp = "http://192.168.0.26/beta/buscar_tu.php?Tipo="+Tu+"";

                temp = temp.replaceAll(" ", "%20");
                buscar3(temp);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });


        crackuser = new ArrayList<Usuarios>();
        spinnerm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                cracktu.clear();
                crackest.clear();
                crackuser.clear();
                selectuser = spinnerm.getItemAtPosition(position).toString();
                limpiar();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // vacio

            }
        });

        Buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                buscar("http://192.168.0.26/beta/buscar_usuarios3.php?Nombre_usuario=" + selectuser + "");
                spinneres.setVisibility(View.VISIBLE);
            }
        });
        Editar = findViewById(R.id.ButtonEditar);
        Editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              editarusuarios("http://192.168.0.26/beta/editar_usuario.php?Nombre_usuario=" + selectuser + "");
              Intent intent = new Intent(EditarU.this, MenuFrag.class);
              startActivity(intent);
              finish();
            }
        });


    }

    //buscar: Busca el usuario y lo verifica en la base de datos.
    private void buscar(String URL) {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        EditNombre.setText(jsonObject.getString("nombre_usuario"));
                        EditTelefono.setText(jsonObject.getString("telefono"));
                        EditFacultad.setText(jsonObject.getString("nombre_carrera"));
                        EditGenero.setText(jsonObject.getString("sexo"));
                        EditCorreo.setText(jsonObject.getString("correo"));
                        EditPassword.setText(jsonObject.getString("password"));
                        State.equals(jsonObject.getString("estado"));
                        EditRol.setText(jsonObject.getString("tipo"));
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "ERROR DE CONEXIÓN", Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
    //buscar4:  Busca el id del estado del usuario en la base de datos.
    private void buscar2(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Idest=(jsonObject.getString("Id_estadou"));
                        //  Toast.makeText(getApplicationContext(), Idcar, Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    //buscar3:  Busca el id del tipo de usuaario en la base de datos.
    private void buscar3(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Idtu=(jsonObject.getString("Id_tipou"));
                        new EditarU.GetUser().execute();
                       // Toast.makeText(getApplicationContext(), Idtu, Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
    //editarusuarios: Edita los datos del usuario existente y los envia a la base de datos.
    private void editarusuarios(String URL) {
        StringRequest StringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
                limpiar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("Telefono", EditTelefono.getText().toString());
                parametros.put("Password", EditPassword.getText().toString());
                parametros.put("Id_estadou", Idest);
                return parametros;
            }
        };
        requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }

    //limpiar: Limpia los editText.
    private void limpiar() {
        EditNombre.setText("");
        EditTelefono.setText("");
        EditFacultad.setText("");
        EditGenero.setText("");
        EditCorreo.setText("");
        EditPassword.setText("");
        EditRol.setText("");
    }

    //cancelar: Devuelve a la activity anterior, cancela el proceso.
    public void cancelar() {
        final Context context = this;
        Atras = findViewById(R.id.ButtonAtras);
        Atras.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, MenuFrag.class);
                startActivity(menu);

            }

        });
    }

    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackuser.size(); i++) {
            lables.add(crackuser.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnerm.setAdapter(spinnerAdapter);


    }

    //GetUser: Trae la informacion de la base de datos de usuarios y lo inserta en el spinner.
    private class GetUser extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String json = jsonParser.makeServiceCall("http://192.168.0.26/beta/listarusuario.php?Id_tipou=" + Idtu + "", ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray usuarios = jsonObj
                                .getJSONArray("users");

                        for (int i = 0; i < usuarios.length(); i++) {
                            JSONObject catObj = (JSONObject) usuarios.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_usuario"),
                                    catObj.getString("nombre_usuario"));
                            crackuser.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }

    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < cracktu.size(); i++) {
            lables.add(cracktu.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnertu.setAdapter(spinnerAdapter);



    }

    //GetCar: Trae la informacion de la base de datos de carreras y lo inserta en el spinner.
    private class GetTu extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listartu.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray tiu = jsonObj
                                .getJSONArray("tu");

                        for (int i = 0; i < tiu.length(); i++) {
                            JSONObject catObj = (JSONObject) tiu.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_tipou"),
                                    catObj.getString("tipo"));
                            cracktu.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }

    private void populateSpinner3() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackest.size(); i++) {
            lables.add(crackest.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinneres.setAdapter(spinnerAdapter);



    }

    //GetCar: Trae la informacion de la base de datos de carreras y lo inserta en el spinner.
    private class GetEst extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarest.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray genero = jsonObj
                                .getJSONArray("est");

                        for (int i = 0; i < genero.length(); i++) {
                            JSONObject catObj = (JSONObject) genero.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_estadou"),
                                    catObj.getString("estado"));
                            crackest.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner3();
        }
    }
}









