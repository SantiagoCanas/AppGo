package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.view.WindowManager;
import com.android.volley.RequestQueue;
import org.json.JSONException;
public class Bienvenida extends Activity {

    private final int DURACION_SPLASH = 6000;

    @Override
    //onCreate: Se encarga de redirigir al usuario segun su rol a su respectivo menu.
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.bienvenida);


        new Handler().postDelayed(new Runnable() {
            public void run() {

                try {
                    if (SesionFragment.jsonObject.getString("crack").equals("1")) {
                        Intent intent = new Intent(Bienvenida.this, MenuFrag.class);
                        startActivity(intent);
                        finish();

                    }  else  if (SesionFragment.jsonObject.getString("crack").equals("2")) {
                        Intent intent = new Intent(Bienvenida.this, MenuFrag2.class);

                        startActivity(intent);
                        finish();

                    }  else  if (SesionFragment.jsonObject.getString("crack").equals("3") || SesionFragment.jsonObject.getString("crack").equals("4")) {
                         Intent intent = new Intent(Bienvenida.this, MenuFrag3.class);
                        startActivity(intent);
                        finish();

                    }



                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }


        }, DURACION_SPLASH);
    }

    }



