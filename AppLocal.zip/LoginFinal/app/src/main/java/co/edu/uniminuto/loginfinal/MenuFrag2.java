package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.navigation.NavigationView;

public class MenuFrag2 extends AppCompatActivity {
    private NavigationView navigationView;
    @Override
    //onCreate: Este metodo se caracteriza por almacenar un navigation que almacena los fragments que utilizara un gestor.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_frag2);

        final DrawerLayout drawerLayout = findViewById(R.id.drawerLayout2);

        findViewById(R.id.imageMenu2).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        navigationView = findViewById(R.id.navigationView2);
        navigationView.setItemIconTintList(null);
        navigationView.getMenu().findItem(R.id.Salir2).setOnMenuItemClickListener(menuItem -> {
            logout();
            return true;
        });
        NavController navController = Navigation.findNavController(this, R.id.navHostFragment2);
        NavigationUI.setupWithNavController(navigationView, navController);
    }
    //logout: Este metodo cierra la sesión actual.
    private void logout() {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }
}