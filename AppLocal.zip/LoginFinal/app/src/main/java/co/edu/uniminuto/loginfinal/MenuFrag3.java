package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.navigation.NavigationView;

public class MenuFrag3 extends AppCompatActivity {
    private NavigationView navigationView;
    @Override
    //onCreate: Este metodo se caracteriza por almacenar un navigation que almacena los fragments que utilizara un usuario.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_frag3);
        final DrawerLayout drawerLayout = findViewById(R.id.drawerLayout3);

        findViewById(R.id.imageMenu3).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        navigationView = findViewById(R.id.navigationView3);
        navigationView.setItemIconTintList(null);
        navigationView.getMenu().findItem(R.id.Salir3).setOnMenuItemClickListener(menuItem -> {
            logout();
            return true;
        });
        NavController navController = Navigation.findNavController(this, R.id.navHostFragment3);
        NavigationUI.setupWithNavController(navigationView, navController);

    }
    //logout: Este metodo cierra la sesión actual.
    private void logout() {
        startActivity(new Intent(getApplicationContext(), MainActivity.class));
        finish();
    }
}