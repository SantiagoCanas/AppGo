package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.speech.tts.TextToSpeech;
import android.telephony.BarringInfo;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Locale;








public class SesionFragment extends Fragment implements Response.Listener<JSONObject>, Response.ErrorListener {

    RequestQueue rq;
    JsonRequest jrq;
    RequestQueue requestQueue;

    public static TextInputLayout CajaUser, CajaPwd;
    MaterialButton btnIniciar;
    public static  JSONObject jsonObject = null;
    public static String Prueba;
    public static String Usuarios;
    public static String Admin;


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public SesionFragment() {
        // Required empty public constructor
    }

    public static SesionFragment newInstance(String param1, String param2) {
        SesionFragment fragment = new SesionFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    //onCreateView: Este metodo se caracteriza por definir las variables para realizar el proceso de ingreso a la aplicacion.
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View vista = inflater.inflate(R.layout.fragment_sesion, container, false);
        CajaUser = vista.findViewById(R.id.txtUser);
        CajaPwd = vista.findViewById(R.id.txtpwd);
        btnIniciar = vista.findViewById(R.id.btnsesion);




        rq = Volley.newRequestQueue(getContext());


        btnIniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( CajaUser.getEditText().getText().toString().trim().equals(""))
                {
                    CajaUser.setError( "Ingrese un Usuario!" );

                    CajaUser.setHint("Porfavor ingrese un Usuario");
                } else   if( CajaPwd.getEditText().getText().toString().trim().equals(""))
                {
                    CajaPwd.setError( "Ingrese Contraseña" );

                    CajaPwd.setHint("Porfavor ingrese una Contraseña");
                } else {
                    validar("http://192.168.0.26/beta/validar_general.php?Correo="+CajaUser.getEditText().getText()+"");

                }






            }
        });

        return vista;

    }

    @Override
    public void onErrorResponse(VolleyError error) {
       Toast.makeText(getContext(),"No se encontro el usuario " + CajaUser.getEditText().getText(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResponse(JSONObject response) {
        User usuario = new User();

      Toast.makeText(getContext(),"Se ha encontrado al usuario " + CajaUser.getEditText().getText(), Toast.LENGTH_SHORT).show();



        JSONArray jsonArray = response.optJSONArray("datos");
        JSONObject jsonObject = null;

        try {
            jsonObject = jsonArray.getJSONObject(0);
            usuario.setUser(jsonObject.optString("correo"));
            usuario.setPwd(jsonObject.optString("password"));


        }catch (JSONException e){
            e.printStackTrace();
        }

        if(TextUtils.isEmpty(CajaUser.getEditText().getText())) {
            CajaUser.setError("Your message");
            return;
        }
        Intent intencion = new Intent(getContext(), Bienvenida.class);
        startActivity(intencion);



    }
    //iniciarSesion: Este metodo se caracteriza por permitir el ingreo a la aplicacion al usuario.
    private void iniciarSesion(){
        String url="http://192.168.0.26/beta/sesion.php?correo="+CajaUser.getEditText().getText()+
                "&password="+CajaPwd.getEditText().getText();
        jrq = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
        rq.add(jrq);

    }

    //buscarid: Busca el id del usuario que ingreso a la aplicacion para utilizarla en otras clases.
    private void buscarid(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Usuarios=(jsonObject.getString("id_usuario"));
                    } catch (JSONException e) {
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), "",Toast.LENGTH_SHORT).show();
            }
        }
        ); JSONObject jsonObject = null;
        requestQueue =  Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }

    //validar: Verifica los datos ingresdos en los editText para ingresar a la aplicacion pero lo clasifica segun su rol para usuario para ser redirigido a su respectivo menu.
    private void validar(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){

                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        if (jsonObject.getString("crack").equals("1") || jsonObject.getString("crack").equals("2") || jsonObject.getString("crack").equals("3") || jsonObject.getString("crack").equals("4")){
                            buscarid("http://192.168.0.26/beta/buscar_usuarios2.php?Correo="+CajaUser.getEditText().getText().toString()+"");
                            iniciarSesion();

                        }
                    } catch (JSONException e) {
                        Toast.makeText(getActivity().getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        }
        );
        requestQueue =  Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }



}
