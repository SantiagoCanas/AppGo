package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.InputFilter;
import android.text.Spanned;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SolicitudesFragment extends Fragment {

    Integer contador = 0;
    Integer contadorP = 0;
    Integer contadorD;
    EditText usuid, cantidad;
    ImageView qrImage;
    Button start, Menos, Mas, CantidadD;
    RequestQueue requestQueue;
    String selectno, selectmarc, selectes, selectse, selectau, idaula, truco, dispo;
    TextView LabelResultado;
    Spinner spinnernd, spinnernm, spinnerne, spinnersed, spinnerau;
    Date c = Calendar.getInstance().getTime();
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss a", Locale.getDefault());
    String formattedDate = df.format(c);
    private ArrayList<Usuarios> crackno;
    private ArrayList<Usuarios> crackmarc;
    private ArrayList<Usuarios> crackesp;
    private ArrayList<Usuarios> crackse;
    private ArrayList<Usuarios> crackau;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public SolicitudesFragment() {
        // Required empty public constructor
    }

      public static SolicitudesFragment newInstance(String param1, String param2) {
        SolicitudesFragment fragment = new SolicitudesFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    //onCreateView: Este metodo se caracteriza por definir las variables para agregar una solicitud.
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_solicitudes, container, false);

        Menos = view.findViewById(R.id.buttonMenosQR);
        Mas = view.findViewById(R.id.buttonMasQR);
        LabelResultado=(TextView)view.findViewById(R.id.TextResul);
        qrImage = (ImageView) view.findViewById(R.id.ImageQR);
        cantidad = (EditText) view.findViewById(R.id.TextCD);
        start = (Button) view.findViewById(R.id.ButtonQR);
        usuid = (EditText) view.findViewById(R.id.TextIdu);
        spinnernd = (Spinner) view.findViewById(R.id.spinnerNd);
        spinnernm = (Spinner) view.findViewById(R.id.spinnerNm);
        spinnerne = (Spinner) view.findViewById(R.id.spinnerNe);
        spinnersed = (Spinner) view.findViewById(R.id.spinnerSede);
        spinnerau = (Spinner) view.findViewById(R.id.spinnerAula);

        crackno = new ArrayList<Usuarios>();
        new SolicitudesFragment.GetNo().execute();

        spinnernd.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                crackse.clear();
                crackau.clear();
                selectno = spinnernd.getItemAtPosition(position).toString();
                new SolicitudesFragment.GetMarco().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackmarc = new ArrayList<Usuarios>();

        spinnernm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                crackse.clear();
                crackau.clear();
                selectmarc = spinnernm.getItemAtPosition(position).toString();
                new SolicitudesFragment.GetEsp().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });



        crackesp = new ArrayList<Usuarios>();
        spinnerne.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                crackse.clear();
                crackau.clear();
                selectes = spinnerne.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_dispositivo.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                buscarherramienta(temp);
                new SolicitudesFragment.GetSed().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });


        crackse = new ArrayList<Usuarios>();
        spinnersed.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                crackse.clear();
                crackau.clear();
                selectse = spinnersed.getItemAtPosition(position).toString();
                new SolicitudesFragment.GetAu().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackau = new ArrayList<Usuarios>();
        spinnerau.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                crackse.clear();
                crackau.clear();
                selectau = spinnerau.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_aulas.php?Ubicacion_aula="+selectau+"";

                temp = temp.replaceAll(" ", "%20");
                buscarid2(temp);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });









        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorD = contadorD-1;
                if (contadorD >= 0) {

                    StringBuilder textToSend = new StringBuilder();

                        textToSend.append("Fecha Solicitud Realizada:"+formattedDate+System.lineSeparator()+"ID Usuario:"+usuid.getText()+System.lineSeparator()+"Nombre Objeto:"+selectno+ System.lineSeparator()+"Marca:"+selectmarc+ System.lineSeparator()+"Especificaciones:"+selectes+ System.lineSeparator()+"Cantidad Prestada:" +contador + System.lineSeparator()+"Aula Prestamo:"+selectau);

                    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                    try {
                        BitMatrix bitMatrix = multiFormatWriter.encode(textToSend.toString(), BarcodeFormat.QR_CODE, 500, 500);
                        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                        qrImage.setImageBitmap(bitmap);
                        qrImage.setVisibility(View.VISIBLE);

                    } catch (WriterException e) {
                        e.printStackTrace();
                    }
                    truco=contador.toString();
                    if (contadorP==0) {
                        agregarsolicitud("http://192.168.0.26/beta/insertar_solicitud.php");
                        contadorP=1;
                        limpiar2();
                    } else if(contadorP!=0) {
                        agregarsolicitud("http://192.168.0.26/beta/insertar_solicitud.php");
                        limpiar2();
                    }
                }
            }
        });




        cantidad.setFilters(new InputFilter[]{new InputFilterMinMax(1, 8)});
        CantidadD = (Button) view.findViewById(R.id.ButtonCantidadD);

        CantidadD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contadorD = Integer.parseInt(cantidad.getText().toString());
                cantidad.setEnabled(false);
            }
        });



        Mas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contador = contador + 1;

                if (contador < 3) {
                    Menos.setEnabled(true);
                    String temp ="http://192.168.0.26/beta/restar_dispositivob.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                    temp = temp.replaceAll(" ", "%20");
                    temp = temp.replaceAll("\r\n", "%0D%0A");
                    temp = temp.replaceAll("\n", "%0A");
                    editar(temp);
                }
                else if (contador >= 3) {
                    Mas.setEnabled(false);
                }
            }
        });

        Menos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                contador = contador - 1;

                if (contador >= 0) {
                    Mas.setEnabled(true);
                    String temp = "http://192.168.0.26/beta/sumar_dispositivob.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                    temp = temp.replaceAll(" ", "%20");
                    temp = temp.replaceAll("\r\n", "%0D%0A");
                    temp = temp.replaceAll("\n", "%0A");
                    editar(temp);
                } else  if (contador <= 0) {
                    Menos.setEnabled(false);
                }
            }
        });

        return view;

    }
    //buscarherramienta: Busca la herramienta en la base de datos en relacion en su cantidad.
    private void buscarherramienta(String URL){
        String temp = "http://192.168.0.26/beta/buscar_dispositivo2.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
        temp = temp.replaceAll(" ", "%20");
        temp = temp.replaceAll("\r\n", "%0D%0A");
        temp = temp.replaceAll("\n", "%0A");
        buscarid(temp);
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        //Acá va la información
                        LabelResultado.setText(jsonObject.getString("cantidad"));
                        qrImage.setImageResource(android.R.color.transparent);
                        start.setEnabled(true);
                    } catch (JSONException e) {
                        Toast.makeText(getActivity().getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), "ERROR DE CONEXIÓN",Toast.LENGTH_SHORT).show();
                LabelResultado.setText("La Herramienta se encuentra agotada");
                qrImage.setImageResource(android.R.color.transparent);
                start.setEnabled(false);
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
    //editar: Este metodo edita la cantidad de objetos que el usuario desea solicitar.
    private void editar(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getActivity().getApplicationContext(),  "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
                String temp = "http://192.168.0.26/beta/buscar_dispositivo.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                buscarherramienta(temp);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("objeto.cantidad",LabelResultado.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(StringRequest);
    }
    //agregarsolicitud: Agre una solicitud en base a los datos del usuario y el objeto.
    private void agregarsolicitud(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getActivity().getApplicationContext(),  "Dispositivo Agregado", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Fecha_solicitud",formattedDate);
                parametros.put("Id_usuario", usuid.getText().toString());
                parametros.put("Id_objeto", dispo);
                parametros.put("Cantidad", contador.toString());
                parametros.put("Id_estados", "1");
                parametros.put("Id_aulas", idaula);
                return parametros;
            }
        };
        RequestQueue requestQueue= Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(StringRequest);
    }
    //buscarid: Busca el id del objeto.
    private void buscarid(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        dispo=(jsonObject.getString("id_objeto"));
                    } catch (JSONException e) {
                        Toast.makeText(getActivity().getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), "ERROR DE CONEXIÓN",Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
    //buscarid2: Buscae el id del aula.
    private void buscarid2(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        idaula=(jsonObject.getString("Id_aula"));
                    } catch (JSONException e) {
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), "",Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
    //limpiar: Limpia los editText.
    private void limpiar(){
        cantidad.setEnabled(true);
        cantidad.setText("");
        usuid.setText("");
        LabelResultado.setText("");
        qrImage.setImageResource(android.R.color.transparent);
    }
    //limpiar2: Limpia los editText.
    private void limpiar2(){
        cantidad.setText(contadorD.toString());
        qrImage.postDelayed(new Runnable(){
                                @Override
                                public void run() {
                                    qrImage.setImageResource(android.R.color.transparent);
                                    if(contadorD == 0){
                                        limpiar();
                                        contadorP=0;
                                        contador=0;
          }
                                    Intent menu = new Intent(getActivity(), MenuFrag.class);
                                    startActivity(menu);
                                }

                            }
                ,6000);

    }

    public class InputFilterMinMax implements InputFilter {
        private int min;
        private int max;
        //InputFilterMinMax: Establece el limite de cantidad de objeto.
        public InputFilterMinMax(int min, int max) {
            this.min = min;
            this.max = max;
        }

        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            //noinspection EmptyCatchBlock
            try {
                int input = Integer.parseInt(dest.subSequence(0, dstart).toString() + source + dest.subSequence(dend, dest.length()));
                if (isInRange(min, max, input))
                    return null;
            } catch (NumberFormatException nfe) { }
            return "";
        }

        private boolean isInRange(int a, int b, int c) {
            return b > a ? c >= a && c <= b : c >= b && c <= a;
        }
    }


    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackno.size(); i++) {
            lables.add(crackno.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnernd.setAdapter(spinnerAdapter);



    }

    //GetNo: Trae la informacion de la base de datos en relacion al nombre del objeto y lo inserta en el spinner.
    private class GetNo extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarnombre.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("noms");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_objeto"),
                                    catObj.getString("nombre_objeto"));
                            crackno.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }
    //populateSpinner2: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackmarc.size(); i++) {
            lables.add(crackmarc.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnernm.setAdapter(spinnerAdapter);



    }

    //GetMarco: Trae la informacion de la base de datos en relacion a la marca del objeto y lo inserta en el spinner.
    private class GetMarco extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarmarcaobj.php?Nombre_objeto="+selectno+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("marcobjs");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("marca"));
                            crackmarc.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }



    //populateSpinner3: Rellena el spinner con la informacion requerida.
    private void populateSpinner3() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackesp.size(); i++) {
            lables.add(crackesp.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_list_item_1, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_list_item_1);


        spinnerne.setAdapter(spinnerAdapter);



    }

    //GetEsp: Trae la informacion de la base de datos en relacion a las especificaciones del objeto y lo inserta en el spinner.
    private class GetEsp extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarespobj.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray espe = jsonObj
                                .getJSONArray("espobj");

                        for (int i = 0; i < espe.length(); i++) {
                            JSONObject catObj = (JSONObject) espe.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("especificaciones"));
                            crackesp.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner3();
        }
    }
    //populateSpinner4: Rellena el spinner con la informacion requerida.
    private void populateSpinner4() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackse.size(); i++) {
            lables.add(crackse.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnersed.setAdapter(spinnerAdapter);



    }

    //GetSed:Trae la informacion de la base de datos en relacion a la sede y lo inserta en el spinner.
    private class GetSed extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarsede.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray sede = jsonObj
                                .getJSONArray("seds");

                        for (int i = 0; i < sede.length(); i++) {
                            JSONObject catObj = (JSONObject) sede.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_sede"),
                                    catObj.getString("nombre_sede"));
                            crackse.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner4();
        }
    }

    //populateSpinner5: Rellena el spinner con la informacion requerida.
    private void populateSpinner5() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackau.size(); i++) {
            lables.add(crackau.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnerau.setAdapter(spinnerAdapter);



    }

    //GetAu: Trae la informacion de la base de datos en relacion a al aula lo inserta en el spinner.
    private class GetAu extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listaraula.php?Nombre_sede="+selectse+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray aulas = jsonObj
                                .getJSONArray("aul");

                        for (int i = 0; i < aulas.length(); i++) {
                            JSONObject catObj = (JSONObject) aulas.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_aula"),
                                    catObj.getString("ubicacion_aula"));
                            crackau.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner5();
        }
    }
}