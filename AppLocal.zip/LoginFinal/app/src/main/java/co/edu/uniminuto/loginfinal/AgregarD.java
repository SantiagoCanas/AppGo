package co.edu.uniminuto.loginfinal;
//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AgregarD extends AppCompatActivity {
    Button Agregar,Cancelar;
    String item,selectca, IdCat, IdObj, Marc, Esp;
    EditText NombreH, Cantidad;
    Spinner spinner, spinnerca, spinnerma, spinneres;
    RequestQueue requestQueue;
    private ArrayList<Usuarios> crackobj;
    private ArrayList<Usuarios> crackma;
    private ArrayList<Usuarios> crackes;
    @Override
    //onCreate: Este metodo se caracteriza por definir las variables para agregar un nuevo objeto u herramienta.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.agregarherramienta);


        NombreH = (EditText) findViewById(R.id.TextNombreH);
        Cantidad = (EditText) findViewById(R.id.TextCantidadH);
        spinner = (Spinner) findViewById(R.id.spinnerTo);
        spinnerca = (Spinner) findViewById(R.id.spinnerCa);
        spinnerma = (Spinner) findViewById(R.id.spinnerCma);
        spinneres = (Spinner) findViewById(R.id.spinnerCes);
        String[] Tipo_dispositivo = {"Seleccione una Opcion","Seleccionar Categoria","Crear Categoria"};
        spinner.setAdapter(new ArrayAdapter<String>(this, R.layout.textview_spinner, Tipo_dispositivo));
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                item = spinner.getItemAtPosition(position).toString();

                if (item.equals("Seleccionar Categoria")) {
                    new AgregarD.GetCat().execute();
                } else if (item.equals("Crear Categoria")) {
                    Intent intent = new Intent(AgregarD.this, Categoria.class);
                    startActivity(intent);
                    finish();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackobj = new ArrayList<Usuarios>();
        spinnerca.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackobj.clear();
                selectca = spinnerca.getItemAtPosition(position).toString();
                new AgregarD.GetMarc().execute();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackma = new ArrayList<Usuarios>();
        spinnerma.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackma.clear();
                Marc = spinnerma.getItemAtPosition(position).toString();
                new AgregarD.GetEsp().execute();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackes = new ArrayList<Usuarios>();
        spinneres.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackes.clear();
                Esp = spinneres.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_cme.php?Categoria="+selectca+"&Marca="+Marc+"&Especificaciones="+Esp+"";

                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                buscarid(temp);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        Agregar = findViewById(R.id.buttonAgregarH);
        Agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
          agregar("http://192.168.0.26/beta/agregar_dispositivo.php");

            }
        });
        cancelar();
    }



    //agregar: Agrega dispositivo a la base de datos con todas sus caracterisitcas.
    private void agregar(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "DISPOSITIVO AGREGADO", Toast.LENGTH_SHORT).show();
                buscarid2("http://192.168.0.26/beta/buscar_objeto.php?Nombre_objeto="+NombreH.getText().toString()+"");



            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Nombre_objeto",NombreH.getText().toString());
                parametros.put("Id_categoria", IdCat);
                return parametros;

            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }

    //agregar: Agrega dispositivo a la base de datos con todas sus caracterisitcas.
    private void agregar2(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "DISPOSITIVO AGREGADO", Toast.LENGTH_SHORT).show();
                limpiar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Id_objeto",IdObj);
                parametros.put("Cantidad", Cantidad.getText().toString());
                return parametros;

            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }

    //limpiar: Limpia los editText.
    private void limpiar(){
        NombreH.setText("");
        Cantidad.setText("");
    }


    //cancelar: Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Cancelar = findViewById(R.id.buttonCancelarH);
        Cancelar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, MenuFrag.class);
                startActivity(menu);

            }

        });
    }
    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackobj.size(); i++) {
            lables.add(crackobj.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnerca.setAdapter(spinnerAdapter);



    }

    //GetCat: Trae la informacion de la base de datos de categorias y lo inserta en el spinner.
    private class GetCat extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarcategoria.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("cats");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_categoria"),
                                    catObj.getString("categoria"));
                            crackobj.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }

    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackma.size(); i++) {
            lables.add(crackma.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnerma.setAdapter(spinnerAdapter);



    }

    //GetFacul: Trae la informacion de la base de datos de facultades y lo inserta en el spinner.
    private class GetMarc extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarmarc2.php?Categoria="+selectca+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("marcs2");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("marca"));
                            crackma.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }

    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner3() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackes.size(); i++) {
            lables.add(crackes.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_list_item_1);


        spinneres.setAdapter(spinnerAdapter);



    }

    //GetFacul: Trae la informacion de la base de datos de facultades y lo inserta en el spinner.
    private class GetEsp extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarespecificaciones2.php?Marca="+Marc+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray espi = jsonObj
                                .getJSONArray("esps");

                        for (int i = 0; i < espi.length(); i++) {
                            JSONObject catObj = (JSONObject) espi.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("especificaciones"));
                            crackes.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner3();
        }
    }

    //buscarid: Busca el id_categoria en la base de datos.
    private void buscarid(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        IdCat=jsonObject.getString("id_categoria");
                       // Toast.makeText(getApplicationContext(),  IdCat, Toast.LENGTH_SHORT).show();
                            } catch (JSONException e) {
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "",Toast.LENGTH_SHORT).show();
            }
        }
        ); JSONObject jsonObject = null;
        requestQueue =  Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
    //buscarid2: Busca el id_objeto en la base de datos.
    private void buscarid2(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        IdObj=jsonObject.getString("Id_objeto");
                        agregar2("http://192.168.0.26/beta/agregar_cantidad.php");
                        Intent intent = new Intent(AgregarD.this, MenuFrag.class);

                        startActivity(intent);

                    } catch (JSONException e) {
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "",Toast.LENGTH_SHORT).show();
            }
        }
        ); JSONObject jsonObject = null;
        requestQueue =  Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }



}

