package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;


public class SolicitudesUFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;
    String hora,minuto;
    RequestQueue requestQueue;
    private final int alarmID = 1;
    private SharedPreferences settings;
    public SolicitudesUFragment() {
        // Required empty public constructor
    }


    public static SolicitudesUFragment newInstance(String param1, String param2) {
        SolicitudesUFragment fragment = new SolicitudesUFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    //onCreateView: Define las variables de los botones del menu de solicitudes del usuario.
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_solicitudes_u, container, false);
        buscar("http://192.168.0.26/beta/buscar_hora.php?Id_usuario="+SesionFragment.Usuarios+"");
        ImageButton imgbtn1 = (ImageButton) view.findViewById(R.id.BtnSoli);

        imgbtn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), Catalogo.class);
                startActivity(menu);

            }

        });

        ImageButton imgbtn2 = (ImageButton) view.findViewById(R.id.BtnVerSoli);

        imgbtn2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), Vsolicitud.class);
                startActivity(menu);

            }

        });


        return view;
    }

    //buscar: Trae la hora y minutos para realizar una notificacion.
    private void buscar(String URL) {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        hora = (jsonObject.getString("Hora"));
                        minuto = (jsonObject.getString("Minutos"));

                        settings = getActivity().getSharedPreferences(getString(R.string.app_name), getActivity().getApplicationContext().MODE_PRIVATE);

                        Date c = Calendar.getInstance().getTime();
                        SimpleDateFormat df = new SimpleDateFormat("HH", Locale.getDefault());
                        String hora2 = df.format(c);
                        SimpleDateFormat df2 = new SimpleDateFormat("mm", Locale.getDefault());
                        String minuto2 = df2.format(c);
                        Calendar today = Calendar.getInstance();


                        if (Integer.parseInt(hora2)>=(Integer.parseInt(hora)+1)) {
                            today.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hora2));
                            today.set(Calendar.MINUTE, Integer.parseInt(minuto2));
                            today.set(Calendar.SECOND, 0);

                            SharedPreferences.Editor edit = settings.edit();
                            edit.putString("hour", hora2);
                            edit.putString("minute", minuto2);

                            //SAVE ALARM TIME TO USE IT IN CASE OF REBOOT
                            edit.putInt("alarmID", alarmID);
                            edit.putLong("alarmTime", today.getTimeInMillis());

                            edit.commit();

                            Toast.makeText(getActivity().getApplicationContext(), hora + ":" + minuto, Toast.LENGTH_LONG).show();

                            Utils.setAlarm(alarmID, today.getTimeInMillis(), getActivity().getApplicationContext());

                        }
                        if (Integer.parseInt(hora2)<(Integer.parseInt(hora)+1)) {
                            today.set(Calendar.HOUR_OF_DAY, Integer.parseInt(hora2));
                            today.set(Calendar.MINUTE, Integer.parseInt(minuto2));
                            today.set(Calendar.SECOND, 0);

                            SharedPreferences.Editor edit = settings.edit();
                            edit.putString("hour", hora2);
                            edit.putString("minute", minuto2);

                            //SAVE ALARM TIME TO USE IT IN CASE OF REBOOT
                            edit.putInt("alarmID", alarmID);
                            edit.putLong("alarmTime", today.getTimeInMillis());

                            edit.commit();

                            Toast.makeText(getActivity().getApplicationContext(), hora + ":" + minuto, Toast.LENGTH_LONG).show();

                            Utils.setAlarm(alarmID, today.getTimeInMillis(), getActivity().getApplicationContext());

                        }
                    } catch (JSONException e) {

                        Toast.makeText(getActivity().getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
}