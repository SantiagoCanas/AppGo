package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

import java.util.Calendar;

public class Fecha extends DialogFragment {

    private DatePickerDialog.OnDateSetListener listener;
    //newInstance: Llama los metodos y realiza la operacion.
    public static Fecha newInstance(DatePickerDialog.OnDateSetListener listener) {
        Fecha fragment = new Fecha();
        fragment.setListener(listener);
        return fragment;
    }
    //setListener: Trae los datos.
    public void setListener(DatePickerDialog.OnDateSetListener listener) {
        this.listener = listener;
    }

    @Override
    @NonNull
    //onCreateDialog: Crea variables de fecha y las envia a listener.
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        return new DatePickerDialog(getActivity(), listener, year, month, day);
    }

}