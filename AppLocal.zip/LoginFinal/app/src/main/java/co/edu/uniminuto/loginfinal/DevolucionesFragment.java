package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.graphics.Bitmap;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class DevolucionesFragment extends Fragment {

    EditText BuscarS;
    ImageView qrImage;
    Button Buscar, Generar;
    RequestQueue requestQueue;
    TextView LabelIds, LabelF, LabelIdu, LabelIdd, LabelCd, LabelIda, LabelMa, LabelEs;
    String Idobj;
    Date c = Calendar.getInstance().getTime();
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss a", Locale.getDefault());
    String formattedDate = df.format(c);

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public DevolucionesFragment() {
        // Required empty public constructor
    }


    public static DevolucionesFragment newInstance(String param1, String param2) {
        DevolucionesFragment fragment = new DevolucionesFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    //onCreateView: Este metodo se caracteriza por definir las variables para agregar una devolucion.
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_devoluciones, container, false);

        LabelIds = (TextView) view.findViewById(R.id.TextResulId);
        LabelF = (TextView) view.findViewById(R.id.TextResulF);
        LabelIdu = (TextView) view.findViewById(R.id.TextResulIdu);
        LabelIdd = (TextView) view.findViewById(R.id.TextResulIdd);
        LabelCd = (TextView) view.findViewById(R.id.TextResulC);
        LabelIda = (TextView) view.findViewById(R.id.TextResulIda);
        LabelMa = (TextView) view.findViewById(R.id.TextResulMa);
        LabelEs = (TextView) view.findViewById(R.id.TextResulEs);
        BuscarS = (EditText) view.findViewById(R.id.TextBuscarS);
        qrImage = (ImageView) view.findViewById(R.id.ImageDQR);
        Buscar = view.findViewById(R.id.ButtonBuscarDQR);
        Generar = view.findViewById(R.id.ButtonDQR);
        Buscar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getActivity().getApplicationContext(), formattedDate, Toast.LENGTH_SHORT).show();
                buscard("http://192.168.0.26/beta/buscar_devolucion.php?Id_solicitud=" + BuscarS.getText().toString() + "");

            }
        });
        Generar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                StringBuilder textToSend = new StringBuilder();
                textToSend.append("ID Solicitud: " + LabelIds.getText().toString() + System.lineSeparator() + "Fecha: " + LabelF.getText().toString() + System.lineSeparator() + "Nombre Usuario: " + LabelIdu.getText().toString() + System.lineSeparator() + "Nombre Objeto: " +LabelIdd.getText().toString() + System.lineSeparator() + "Cantidad: " + LabelCd.getText().toString() + System.lineSeparator() + "Aula: " + LabelIda.getText().toString());


                MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                try {
                    BitMatrix bitMatrix = multiFormatWriter.encode(textToSend.toString(), BarcodeFormat.QR_CODE, 500, 500);
                    BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                    Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                    qrImage.setImageBitmap(bitmap);
                    qrImage.setVisibility(View.VISIBLE);

                } catch (WriterException e) {
                    e.printStackTrace();
                }

                agregardevolucion("http://192.168.0.26/beta/insertar_devolucion.php?Id_solicitud="+BuscarS.getText().toString()+"&Fecha_devolucion="+formattedDate+"");
                String temp = "http://192.168.0.26/beta/sumar_devolucion.php?Cantidad="+LabelCd.getText()+"&Nombre_objeto="+LabelIdd.getText()+"&Marca="+LabelMa.getText()+"&Especificaciones="+LabelEs.getText()+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                agregarcd(temp);
                limpiar();

            }
        });

        return view;
    }
    //buscar: Busca el los datos de la solicitud en la base de datos y los muestra.
    private void buscar(String URL) {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        LabelIds.setText(jsonObject.getString("id_solicitud"));
                        LabelF.setText(jsonObject.getString("fecha_solicitud"));
                        LabelIdu.setText(jsonObject.getString("nombre_usuario"));
                        LabelIdd.setText(jsonObject.getString("nombre_objeto"));
                        LabelMa.setText(jsonObject.getString("marca"));
                        LabelEs.setText(jsonObject.getString("especificaciones"));
                        LabelCd.setText(jsonObject.getString("cantidad"));
                        LabelIda.setText(jsonObject.getString("ubicacion_aula"));
                    } catch (JSONException e) {

               Toast.makeText(getActivity().getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), "ERROR DE CONEXIÓN", Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
    //agregardevolucion: Agrega una devolucion en relacion a los datos visualizados en en el metodo buscar.
    private void agregardevolucion(String URL) {
        StringRequest StringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getActivity().getApplicationContext(), "Devolución Realizada", Toast.LENGTH_SHORT).show();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("id_solicitud", LabelIds.getText().toString());
                parametros.put("Fecha_devolucion", formattedDate);
                return parametros;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(StringRequest);
    }
    //agregarcd: Suma la devolucion en relacion al id del objeto y nombre.
    private void agregarcd(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity().getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Cantidad",LabelCd.getText().toString());
                parametros.put("Nombre_objeto",LabelIdd.getText().toString());
                parametros.put("Marca",LabelMa.getText().toString());
                parametros.put("Especificaciones",LabelEs.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(StringRequest);
    }

    //limpiar: Limpia los editText.
    private void limpiar() {
        LabelIds.setText("");
        LabelF.setText("");
        LabelIdu.setText("");
        LabelIdd.setText("");
        LabelCd.setText("");
        LabelIda.setText("");
        LabelMa.setText("");
        LabelEs.setText("");
        BuscarS.setText("");

        qrImage.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    qrImage.setImageResource(android.R.color.transparent);

                                }

                            }
                , 6000);
    }
    //limpiar2: Limpia los editText.
    private void limpiar2() {
        BuscarS.setText("");
    }
    //buscard: Busca en la base de datos si ya se registro la devolucion de una solicitud.
    private void buscard(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        if (jsonObject.getString("id_solicitud").equals(BuscarS.getText().toString())){
                            Toast.makeText(getActivity().getApplicationContext(), "LA SOLICITUD SE ENCUENTRA REGISTRADA", Toast.LENGTH_SHORT).show();
                            limpiar2();
                        }


                    } catch (JSONException e) {
                        Toast.makeText(getActivity().getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                buscar("http://192.168.0.26/beta/buscar_solicitud.php?Id_solicitud=" + BuscarS.getText().toString() + "");

            }
        }
        );
        requestQueue =  Volley.newRequestQueue(getActivity().getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }
}

