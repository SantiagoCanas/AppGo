package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;


public class GestUFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public GestUFragment() {
        // Required empty public constructor
    }


    public static GestUFragment newInstance(String param1, String param2) {
        GestUFragment fragment = new GestUFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    //onCreateView: Define las variables de los botones del menu de gestion de usuarios del administrador.
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_gest_u, container, false);

        ImageButton imgbtn1 = (ImageButton) view.findViewById(R.id.BtnCrearU);

        imgbtn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), CrearU.class);
                startActivity(menu);

            }

        });

        ImageButton imgbtn2 = (ImageButton) view.findViewById(R.id.BtnEditarU);

        imgbtn2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), EditarU.class);
                startActivity(menu);

            }

        });

        ImageButton imgbtn3 = (ImageButton) view.findViewById(R.id.BtnVeru);

        imgbtn3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), VisualizarU.class);
                startActivity(menu);

            }

        });




        return view;
    }
}