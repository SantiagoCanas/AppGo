package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;


public class DevolucionesUFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public DevolucionesUFragment() {
        // Required empty public constructor
    }


    public static DevolucionesUFragment newInstance(String param1, String param2) {
        DevolucionesUFragment fragment = new DevolucionesUFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    //onCreateView: Define las variables de los botones del menu de devoluciones del usuario.
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_devoluciones_u, container, false);

        ImageButton imgbtn1 = (ImageButton) view.findViewById(R.id.BtnDevolverH);

        imgbtn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), Devolver.class);
                startActivity(menu);

            }

        });

        ImageButton imgbtn2 = (ImageButton) view.findViewById(R.id.BtnVDevo);

        imgbtn2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), Vdevolucion.class);
                startActivity(menu);

            }

        });



        return view;

    }

}