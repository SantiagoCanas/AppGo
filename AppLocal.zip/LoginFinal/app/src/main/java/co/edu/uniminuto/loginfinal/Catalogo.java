package co.edu.uniminuto.loginfinal;
//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Catalogo extends AppCompatActivity {
    ListView listView3;
    Button Atras, Siguiente;

    @Override
    //onCreate: Contiene Spinners que traen informacion de la base de datos para que el usuario pueda ver aquellos objetos que puede solicitar.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.catalogo);
        salir();
        siguiente();
        listView3 = (ListView) findViewById(R.id.listViewS);

        downloadJSON("http://192.168.0.26/beta/visualizar_dispositivos.php?");



    }
    //downloadJSON: Trae archivos tipo json de la base de datos para poder visualizarlos.
    private void downloadJSON(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                try {
                    loadIntoListView(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }
    //loadIntoListView: Carga dentro de una las diferentes caracteristicas que desean ser consultadas por el usuario.
    private void loadIntoListView(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() + " Objeto: " + obj.getString("nombre_objeto") + System.lineSeparator()  + " Marca: " + obj.getString("marca")+ System.lineSeparator()  + " Especificaciones: " + obj.getString("especificaciones")+ System.lineSeparator()  + " Cantidad Disponible: " + obj.getString("cantidad");
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView3.setAdapter(arrayAdapter);
    }
    //salir: Metodo para retroceder o cancelar proceso.
       public void salir(){
        final Context context = this;
        Atras = findViewById(R.id.ButtonSiguienteVD);
        Atras.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                onBackPressed();

            }

        });
    }



    //siguiente: Avanza al intent Escaner
    public void siguiente(){
        final Context context = this;
        Siguiente = findViewById(R.id.ButtonSiguiente);
        Siguiente.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Catalogo.this, Escaner.class);
                startActivity(intent);
                finish();

            }

        });
    }
}
