package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class VerD extends AppCompatActivity {
    ListView listView3;
    Button Atras;
    Spinner spinner, spinner2, spinner3;
    String  state, selectno, selectmarc, selectes;

    private ArrayList<Usuarios> crackno;
    private ArrayList<Usuarios> crackmarc;
    private ArrayList<Usuarios> crackesp;
    @Override
    //onCreate: Este metodo se caracteriza traer los datos requeridos segun el id al momento de iniciar sesion.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verherramienta);
        salir();
        listView3 = (ListView) findViewById(R.id.listView2);
        spinner = (Spinner) findViewById(R.id.spinnerVNom);
        spinner2 = (Spinner) findViewById(R.id.spinnerVCat);
        spinner3= (Spinner) findViewById(R.id.spinnerVMarc);




        crackno = new ArrayList<Usuarios>();
        new VerD.GetNo().execute();

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                selectno = spinner.getItemAtPosition(position).toString();
                new VerD.GetMarco().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackmarc = new ArrayList<Usuarios>();

        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                selectmarc = spinner2.getItemAtPosition(position).toString();
                new VerD.GetEsp().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });



        crackesp = new ArrayList<Usuarios>();
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                selectes = spinner3.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/visualizar_dispositivos2.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                downloadJSON(temp);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });






    }

    //downloadJSON: Trae los datos de la base de datos en formano JSON y lo adapta a java.
    private void downloadJSON(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                try {
                    loadIntoListView(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }
    //loadIntoListView: Carga los datos de la base de datos en la lista.
    private void loadIntoListView(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Id Objeto: " +obj.getString("id_objeto") + System.lineSeparator() + " Nombre Objeto: " + obj.getString("nombre_objeto") + System.lineSeparator()  + " Marca: " + obj.getString("marca") + System.lineSeparator() + " Especificaciones: " + obj.getString("especificaciones")  + System.lineSeparator()  + " Buen Estado: " + obj.getString("bueno") + System.lineSeparator()  + " Dañados: " + obj.getString("malo") + System.lineSeparator()  + " En Revisión: " + obj.getString("regular");
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView3.setAdapter(arrayAdapter);
    }

    //salir: Devuelve a la activity anterior, cancela el proceso.
    public void salir(){
        final Context context = this;
        Atras = findViewById(R.id.ButtonAtrasVD);
        Atras.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                onBackPressed();

            }

        });
    }


    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackno.size(); i++) {
            lables.add(crackno.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner.setAdapter(spinnerAdapter);



    }

    //GetNo: Trae la informacion de la base de datos en relacion al nombre del objeto y lo inserta en el spinner.
    private class GetNo extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarnombre.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("noms");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_objeto"),
                                    catObj.getString("nombre_objeto"));
                            crackno.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }
    //populateSpinner2: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackmarc.size(); i++) {
            lables.add(crackmarc.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner2.setAdapter(spinnerAdapter);



    }

    //GetMarco: Trae la informacion de la base de datos en relacion a la marca del objeto y lo inserta en el spinner.
    private class GetMarco extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarmarcaobj.php?Nombre_objeto="+selectno+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("marcobjs");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("marca"));
                            crackmarc.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }



    //populateSpinner3: Rellena el spinner con la informacion requerida.
    private void populateSpinner3() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackesp.size(); i++) {
            lables.add(crackesp.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_list_item_1);


        spinner3.setAdapter(spinnerAdapter);



    }

    //GetEsp: Trae la informacion de la base de datos en relacion a las especificaciones del objeto y lo inserta en el spinner.
    private class GetEsp extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarespobj.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray espe = jsonObj
                                .getJSONArray("espobj");

                        for (int i = 0; i < espe.length(); i++) {
                            JSONObject catObj = (JSONObject) espe.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("especificaciones"));
                            crackesp.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner3();
        }
    }

}
