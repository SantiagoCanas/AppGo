package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Marca extends AppCompatActivity {
    Button Agregar, Cancelar;
    EditText Marca, Especificaciones;
    RequestQueue requestQueue;
    @Override
    //onCreate: Este metodo se caracteriza por definir las variables para agregar una categoria.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.marca);
        Marca = (EditText) findViewById(R.id.TextMarca);
        Especificaciones = (EditText) findViewById(R.id.TextMespecificaciones);
        cancelar();



        Agregar = findViewById(R.id.buttonAgregarMarc);
        Agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregar("http://192.168.0.26/beta/agregar_marca.php");
                Intent intent = new Intent(Marca.this, Categoria.class);

                startActivity(intent);

            }
        });
        cancelar();
    }
        //agregar: Agrega una categoria a la base de datos con todas sus caracterisitcas.
    private void agregar(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "MARCA AGREGADA", Toast.LENGTH_SHORT).show();
                limpiar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Marca",Marca.getText().toString());
                parametros.put("Especificaciones", Especificaciones.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }
    //limpiar: Limpia los editText.
    private void limpiar(){
        Marca.setText("");
        Especificaciones.setText("");
    }



    //cancelar: Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Cancelar = findViewById(R.id.buttonCancelarMarc);
        Cancelar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, Categoria.class);
                startActivity(menu);

            }

        });
    }
}

