package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Categoria extends AppCompatActivity {
    Button Agregar, Cancelar;
    EditText Tipoc;
    String item, Marc, Idm, Esp;
    Spinner spinnercm, spinnertm,  spinnerem;
    RequestQueue requestQueue;
    private ArrayList<Usuarios> crackmarc;
    private ArrayList<Usuarios> crackesp;
    @Override
    //onCreate: Este metodo se caracteriza por definir las variables para agregar una categoria.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.categoria);
        Agregar = findViewById(R.id.buttonAgregarCat);
        Cancelar = findViewById(R.id.buttonCancelarCat);
        Tipoc = (EditText) findViewById(R.id.TextTipoc);
        spinnercm = (Spinner) findViewById(R.id.spinnerCm);
        spinnertm = (Spinner) findViewById(R.id.spinnerTm);
        spinnerem = (Spinner) findViewById(R.id.spinnerEm);
        cancelar();
        String[] Tipo_marca = {"Seleccione una Opcion","Seleccionar Marca","Crear Marca"};
        spinnercm.setAdapter(new ArrayAdapter<String>(this, R.layout.textview_spinner, Tipo_marca));
        spinnercm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                item = spinnercm.getItemAtPosition(position).toString();

                if (item.equals("Seleccionar Marca")) {
                    new Categoria.GetMarc().execute();
                } else if (item.equals("Crear Marca")) {
                    Intent intent = new Intent(Categoria.this, Marca.class);
                    startActivity(intent);
                    finish();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });
        crackmarc = new ArrayList<Usuarios>();
        spinnertm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                crackmarc.clear();
                crackesp.clear();
                Marc = spinnertm.getItemAtPosition(position).toString();

                new Categoria.GetEsp().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });


        crackesp = new ArrayList<Usuarios>();
        spinnerem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                crackmarc.clear();
                crackesp.clear();
                Esp = spinnerem.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_marca.php?Marca="+Marc+"&Especificaciones="+Esp+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
               // Toast.makeText(getApplicationContext(),  temp, Toast.LENGTH_SHORT).show();
                buscare(temp);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });



        Agregar = findViewById(R.id.buttonAgregarCat);
        Agregar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                agregar("http://192.168.0.26/beta/agregar_categoria.php");
                Intent intent = new Intent(Categoria.this, AgregarD.class);

                startActivity(intent);

            }
        });
        cancelar();
    }

    //agregar: Agrega una categoria a la base de datos con todas sus caracterisitcas.
    private void agregar(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "CATEGORIA AGREGADA", Toast.LENGTH_SHORT).show();
                limpiar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Categoria", Tipoc.getText().toString());
                parametros.put("Id_marca",Idm);
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }
    //limpiar: Limpia los editText.
    private void limpiar(){
        Tipoc.setText("");
    }


    //cancelar: Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Cancelar = findViewById(R.id.buttonCancelarCat);
        Cancelar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, AgregarD.class);
                startActivity(menu);

            }

        });
    }

    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackmarc.size(); i++) {
            lables.add(crackmarc.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnertm.setAdapter(spinnerAdapter);



    }

    //GetFacul: Trae la informacion de la base de datos de facultades y lo inserta en el spinner.
    private class GetMarc extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarmarc.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("marcs");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("marca"));
                            crackmarc.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }

    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackesp.size(); i++) {
            lables.add(crackesp.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_list_item_1, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_list_item_1);


        spinnerem.setAdapter(spinnerAdapter);



    }

    //GetFacul: Trae la informacion de la base de datos de facultades y lo inserta en el spinner.
    private class GetEsp extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarespecificaciones.php?Marca="+Marc+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray espi = jsonObj
                                .getJSONArray("esps");

                        for (int i = 0; i < espi.length(); i++) {
                            JSONObject catObj = (JSONObject) espi.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("especificaciones"));
                            crackesp.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }
    //buscare:  Busca las especificaciones de la Marca en la base de datos.
    private void buscare(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                         Idm=(jsonObject.getString("Id_marca"));
                       // Toast.makeText(getApplicationContext(),  Idm, Toast.LENGTH_SHORT).show();
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
}

