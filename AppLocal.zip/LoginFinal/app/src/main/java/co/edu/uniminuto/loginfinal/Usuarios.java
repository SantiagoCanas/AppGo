package co.edu.uniminuto.loginfinal;

public class Usuarios {
    private int id;
    private String name;

    public Usuarios(){}
    //Usuarios: Trae los parametros de los set de id y nombre.
    public Usuarios(int id, String name){
        this.setId(id);
        this.setName(name);
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
