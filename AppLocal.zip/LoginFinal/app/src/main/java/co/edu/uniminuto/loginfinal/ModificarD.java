package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ModificarD extends AppCompatActivity {


    RequestQueue requestQueue;
    Button Cancelar,Eliminar, Menos, Mas;
    TextView Cantidad;
    Spinner spinner2, spinnerno, spinnerma, spinneres;
    String item, selectno, selectmarc, selectes;
    RadioGroup RadioG;
    RadioButton RadioD, RadioR;
    private ArrayList<Usuarios> crackno;
    private ArrayList<Usuarios> crackmarc;
    private ArrayList<Usuarios> crackesp;
    @Override
    //onCreate: Este metodo se caracteriza por definir las variables para editar los objetos.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modificarherramienta);


        Cantidad=(TextView)findViewById(R.id.TextCantidadH2);
        Menos = findViewById(R.id.buttonMenos);
        Mas = findViewById(R.id.buttonMas);
        RadioG = (RadioGroup) findViewById(R.id.RadioGroupEs);
        RadioD = (RadioButton) findViewById(R.id.RadioDa);
        RadioR = (RadioButton) findViewById(R.id.RadioRev);
        spinner2 = (Spinner) findViewById(R.id.spinner2);
        spinnerno = (Spinner) findViewById(R.id.spinner2No);
        spinnerma = (Spinner) findViewById(R.id.spinner2Ma);
        spinneres = (Spinner) findViewById(R.id.spinner2Es);
        String[] Estado = {" ","Buen Estado","Dañado","Revisión"};
        spinner2.setAdapter(new ArrayAdapter<String>(this, R.layout.textview_spinner, Estado));
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                item = spinner2.getItemAtPosition(position).toString();
               // Toast.makeText(adapterView.getContext(), (String) adapterView.getItemAtPosition(position), Toast.LENGTH_SHORT).show();
                if (item == "Buen Estado"){
                    RadioD.setVisibility(View.VISIBLE);
                    RadioR.setVisibility(View.VISIBLE);
                    RadioD.setFocusable(true);
                    RadioR.setFocusable(true);
                    String temp = "http://192.168.0.26/beta/buscar_dispositivo.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                    temp = temp.replaceAll(" ", "%20");
                    temp = temp.replaceAll("\r\n", "%0D%0A");
                    temp = temp.replaceAll("\n", "%0A");
                    buscar(temp);

                }

                if (item == "Dañado"){
                    RadioD.setVisibility(View.INVISIBLE);
                    RadioR.setVisibility(View.VISIBLE);
                    RadioD.setFocusable(false);
                    RadioR.setFocusable(true);
                    String temp = "http://192.168.0.26/beta/buscar_dispositivod.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                    temp = temp.replaceAll(" ", "%20");
                    temp = temp.replaceAll("\r\n", "%0D%0A");
                    temp = temp.replaceAll("\n", "%0A");
                    buscar(temp);
                }

                if (item == "Revisión"){
                    RadioD.setVisibility(View.VISIBLE);
                    RadioR.setVisibility(View.INVISIBLE);
                    RadioD.setFocusable(true);
                    RadioR.setFocusable(false);
                    String temp = "http://192.168.0.26/beta/buscar_dispositivor.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                    temp = temp.replaceAll(" ", "%20");
                    temp = temp.replaceAll("\r\n", "%0D%0A");
                    temp = temp.replaceAll("\n", "%0A");
                    buscar(temp);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });
        crackno = new ArrayList<Usuarios>();
        new ModificarD.GetNo().execute();

        spinnerno.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                selectno = spinnerno.getItemAtPosition(position).toString();
                Cantidad.setText("");
                spinner2.setSelection(0,true);
                new ModificarD.GetMarco().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackmarc = new ArrayList<Usuarios>();

        spinnerma.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                selectmarc = spinnerma.getItemAtPosition(position).toString();
                Cantidad.setText("");
                spinner2.setSelection(0,true);
                new ModificarD.GetEsp().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });



        crackesp = new ArrayList<Usuarios>();
        spinneres.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackno.clear();
                crackmarc.clear();
                crackesp.clear();
                selectes = spinneres.getItemAtPosition(position).toString();
                Cantidad.setText("");
                spinner2.setSelection(0,true);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });






        Eliminar = findViewById(R.id.buttonEliminarH);
        Eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                eliminar("http://192.168.0.26/beta/eliminar_dispositivo.php?Nombre_objeto="+selectno+"");
            }
        });
        cancelar();



        RadioG.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener(){

            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (checkedId == R.id.RadioDis && item == "Buen Estado"){

                    Mas.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {

                            String temp = "http://192.168.0.26/beta/sumar_dispositivob.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar(temp);
                        }
                    });

                    Menos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/restar_dispositivob.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar(temp);
                        }
                    });


                }else if (checkedId == R.id.RadioDa && item == "Buen Estado"){


                    Mas.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/sumar_dispositivobd.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar(temp);
                        }
                    });

                    Menos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/restar_dispositivobd.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar(temp);
                        }
                    });

                }else if (checkedId == R.id.RadioRev && item == "Buen Estado"){

                    Mas.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/sumar_dispositivobr.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar(temp);
                        }
                    });

                    Menos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/restar_dispositivobr.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar(temp);
                        }
                    });


                }
                else if (checkedId == R.id.RadioDis && item == "Dañado"){

                    Mas.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/sumar_dispositivodb.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar2(temp);
                        }
                    });

                    Menos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/restar_dispositivodb.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar2(temp);
                        }
                    });


                }   else if (checkedId == R.id.RadioRev && item == "Dañado"){

                    Mas.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/sumar_dispositivodr.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar2(temp);
                        }
                    });

                    Menos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/restar_dispositivodr.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar2(temp);
                        }
                    });


                }
                else if (checkedId == R.id.RadioDa && item == "Revisión"){

                    Mas.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/sumar_dispositivord.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar3(temp);
                        }
                    });

                    Menos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/restar_dispositivord.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar3(temp);
                        }
                    });


                } else if (checkedId == R.id.RadioDis && item == "Revisión"){

                    Mas.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/sumar_dispositivorb.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar3(temp);
                        }
                    });

                    Menos.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String temp = "http://192.168.0.26/beta/restar_dispositivorb.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                            temp = temp.replaceAll(" ", "%20");
                            temp = temp.replaceAll("\r\n", "%0D%0A");
                            temp = temp.replaceAll("\n", "%0A");
                            editar3(temp);
                        }
                    });


                }

            }

        });



    }



    //buscar: Busca la cantidad de un objeto segun su estado en la base de datos.
    private void buscar(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Cantidad.setText(jsonObject.getString("cantidad"));
                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), "ERROR DE CONEXIÓN",Toast.LENGTH_SHORT).show();
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }
    //editar: Edita los datos del objeto existente y los envia a la base de datos.
    private void editar(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
                String temp = "http://192.168.0.26/beta/buscar_dispositivo.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                buscar(temp);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Cantidad",Cantidad.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }
    //editar: Edita los datos del objeto existente y los envia a la base de datos.
    private void editar2(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
                String temp = "http://192.168.0.26/beta/buscar_dispositivod.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                buscar(temp);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Cantidad",Cantidad.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }

    //editar: Edita los datos del objeto existente y los envia a la base de datos.
    private void editar3(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
                String temp = "http://192.168.0.26/beta/buscar_dispositivor.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"&Especificaciones="+selectes+"";
                temp = temp.replaceAll(" ", "%20");
                temp = temp.replaceAll("\r\n", "%0D%0A");
                temp = temp.replaceAll("\n", "%0A");
                buscar(temp);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Cantidad",Cantidad.getText().toString());
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }
    //eliminar: Edita los datos del objeto existente y los elimina de la base de datos.
    private void eliminar(String URL){
        StringRequest StringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>(){
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(),  "ELIMINADO CON EXITO", Toast.LENGTH_SHORT).show();
                limpiar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),error.toString(),Toast.LENGTH_SHORT).show();
            }
        }){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> parametros= new HashMap<String,String>();
                parametros.put("Nombre",selectno);
                return parametros;
            }
        };
        requestQueue= Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);
    }
    //limpiar: Limpia los editText.
    private void limpiar(){
        Cantidad.setText("");
        spinner2.setSelection(0,true);
        RadioG.clearCheck();
    }
    //cancelar: Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Cancelar = findViewById(R.id.buttonCancelarH2);
        Cancelar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                onBackPressed();

            }

        });
    }


    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackno.size(); i++) {
            lables.add(crackno.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnerno.setAdapter(spinnerAdapter);



    }

    //GetNo: Trae la informacion de la base de datos en relacion al nombre del objeto y lo inserta en el spinner.
    private class GetNo extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarnombre.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("noms");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_objeto"),
                                    catObj.getString("nombre_objeto"));
                            crackno.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }
    //populateSpinner2: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackmarc.size(); i++) {
            lables.add(crackmarc.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinnerma.setAdapter(spinnerAdapter);



    }

    //GetMarco: Trae la informacion de la base de datos en relacion a la marca del objeto y lo inserta en el spinner.
    private class GetMarco extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarmarcaobj.php?Nombre_objeto="+selectno+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("marcobjs");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("marca"));
                            crackmarc.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }



    //populateSpinner3: Rellena el spinner con la informacion requerida.
    private void populateSpinner3() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackesp.size(); i++) {
            lables.add(crackesp.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinneres.setAdapter(spinnerAdapter);



    }

    //GetEsp: Trae la informacion de la base de datos en relacion a las especificaciones del objeto y lo inserta en el spinner.
    private class GetEsp extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarespobj.php?Nombre_objeto="+selectno+"&Marca="+selectmarc+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray espe = jsonObj
                                .getJSONArray("espobj");

                        for (int i = 0; i < espe.length(); i++) {
                            JSONObject catObj = (JSONObject) espe.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_marca"),
                                    catObj.getString("especificaciones"));
                            crackesp.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner3();
        }
    }


}









