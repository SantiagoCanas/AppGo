package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;


public class HerramientasFragment extends Fragment {


    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public HerramientasFragment() {
        // Required empty public constructor
    }


    public static HerramientasFragment newInstance(String param1, String param2) {
        HerramientasFragment fragment = new HerramientasFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    //onCreateView: Define las variables de los botones del menu de gestion de herramientas del administrador o gestor.
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_herramientas, container, false);

        ImageButton imgbtn1 = (ImageButton) view.findViewById(R.id.BtnCrearH);

        imgbtn1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), AgregarD.class);
                startActivity(menu);

            }

        });

        ImageButton imgbtn2 = (ImageButton) view.findViewById(R.id.BtnEditarH);

        imgbtn2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), ModificarD.class);
                startActivity(menu);

            }

        });

        ImageButton imgbtn3 = (ImageButton) view.findViewById(R.id.BtnVerH);

        imgbtn3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(getActivity(), VerD.class);
                startActivity(menu);

            }

        });

        return view;
    }
}