package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CrearU extends AppCompatActivity {
    Button Validar, Cancelar;
    EditText Nombre, Telefono, Correo, Password;
    String Facultad, Carrera, Genero, Tu, State, Idcar, Idgen, Idest, Idtu;
    Spinner spinner, spinner2, spinner3, spinner4, spinner5;
    RequestQueue requestQueue;
    private ArrayList<Usuarios> crackfacul;
    private ArrayList<Usuarios> crackcar;
    private ArrayList<Usuarios> crackgen;
    private ArrayList<Usuarios> cracktu;
    private ArrayList<Usuarios> crackest;
    @Override
    //onCreate: Este metodo se caracteriza por definir las variables para agregar un nuevo usuario.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.crearusuario);
        Nombre = (EditText) findViewById(R.id.TextNombre);
        Telefono = (EditText) findViewById(R.id.TextTel);
        Correo = (EditText) findViewById(R.id.TextCorreo);
        Password = (EditText) findViewById(R.id.TextPassword);
        Validar = findViewById(R.id.buttonValidar);
        spinner = (Spinner) findViewById(R.id.spinnerF);
        spinner2 = (Spinner) findViewById(R.id.spinnerG);
        spinner3 = (Spinner) findViewById(R.id.spinnerR);
        spinner4 = (Spinner) findViewById(R.id.spinnerC);
        spinner5 = (Spinner) findViewById(R.id.spinnerTu);
        cancelar();
        crackfacul = new ArrayList<Usuarios>();
        new CrearU.GetFacul().execute();
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackfacul.clear();
                Facultad = spinner.getItemAtPosition(position).toString();
                new CrearU.GetCar().execute();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackcar = new ArrayList<Usuarios>();
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackfacul.clear();
                crackcar.clear();
                crackgen.clear();
                cracktu.clear();
                crackest.clear();
                Carrera = spinner4.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_carrera.php?Nombre_carrera="+Carrera+"";

                temp = temp.replaceAll(" ", "%20");
                buscar(temp);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        new CrearU.GetGen().execute();
        crackgen = new ArrayList<Usuarios>();
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackfacul.clear();
                crackcar.clear();
                crackgen.clear();
                cracktu.clear();
                crackest.clear();
                Genero = spinner2.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_gen.php?Sexo="+Genero+"";

                temp = temp.replaceAll(" ", "%20");
                buscar2(temp);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });


        new CrearU.GetEst().execute();
        crackest = new ArrayList<Usuarios>();
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {    crackfacul.clear();
                crackcar.clear();
                crackgen.clear();
                cracktu.clear();
                crackest.clear();
                State = spinner3.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_est.php?Estado="+State+"";

                temp = temp.replaceAll(" ", "%20");
                buscar4(temp);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        new CrearU.GetTu().execute();
        cracktu = new ArrayList<Usuarios>();
        spinner5.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {    crackfacul.clear();
                crackcar.clear();
                crackgen.clear();
                cracktu.clear();
                crackest.clear();
                Tu = spinner5.getItemAtPosition(position).toString();
                String temp = "http://192.168.0.26/beta/buscar_tu.php?Tipo="+Tu+"";

                temp = temp.replaceAll(" ", "%20");
                buscar3(temp);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });


        Validar = findViewById(R.id.buttonValidar);
        Validar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                usuario("http://192.168.0.26/beta/insertar_usuarios.php");
            }
        });

    }
    //usuario: Obtiene los valores de las variables y las redirige para crear un usuario.
    private void usuario(String URL) {
        StringRequest StringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                Toast.makeText(getApplicationContext(), "OPERACION EXITOSA", Toast.LENGTH_SHORT).show();
                limpiar();
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.toString(), Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> parametros = new HashMap<String, String>();
                parametros.put("Nombre_usuario", Nombre.getText().toString());
                parametros.put("Telefono", Telefono.getText().toString());
                parametros.put("Id_carrera", Idcar);
                parametros.put("Id_genero", Idgen);
                parametros.put("Correo", Correo.getText().toString());
                parametros.put("Password", Password.getText().toString());
                parametros.put("Id_tipou", Idtu);
                parametros.put("Id_estadou", Idest);
                return parametros;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(StringRequest);

    }

    //limpiar: Limpia los editText.
    private void limpiar() {
        Nombre.setText("");
        spinner.setSelection(0,true);
        spinner2.setSelection(0,true);
        spinner3.setSelection(0,true);
        spinner4.setSelection(0,true);
        spinner5.setSelection(0,true);
        Telefono.setText("");
        Correo.setText("");
        Password.setText("");
    }


    //cancelar: Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Cancelar = findViewById(R.id.buttonCancelarU);
        Cancelar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, MenuFrag.class);
                startActivity(menu);

            }

        });
    }


    //buscar:  Busca el id de la carrera en la base de datos.
    private void buscar(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Idcar=(jsonObject.getString("Id_carrera"));
                      //  Toast.makeText(getApplicationContext(), Idcar, Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    //buscar2:  Busca el id del genero en la base de datos.
    private void buscar2(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Idgen=(jsonObject.getString("Id_genero"));
                        //  Toast.makeText(getApplicationContext(), Idcar, Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    //buscar3:  Busca el id del tipo de usuaario en la base de datos.
    private void buscar3(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Idtu=(jsonObject.getString("Id_tipou"));
                        //  Toast.makeText(getApplicationContext(), Idcar, Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }

    //buscar4:  Busca el id del estado del usuario en la base de datos.
    private void buscar4(String URL){
        JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response){
                JSONObject jsonObject = null;
                for (int i = 0; i < response.length(); i++) {
                    try {
                        jsonObject = response.getJSONObject(i);
                        Idest=(jsonObject.getString("Id_estadou"));
                        //  Toast.makeText(getApplicationContext(), Idcar, Toast.LENGTH_SHORT).show();


                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
            }
        }
        );
        requestQueue =  Volley.newRequestQueue(this);
        requestQueue.add(jsonArrayRequest);
    }


    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackfacul.size(); i++) {
            lables.add(crackfacul.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner.setAdapter(spinnerAdapter);



    }

    //GetFacul: Trae la informacion de la base de datos de facultades y lo inserta en el spinner.
    private class GetFacul extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarfacultad.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("facul");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_facultad"),
                                    catObj.getString("nombre_facultad"));
                            crackfacul.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }
    //populateSpinner2: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackcar.size(); i++) {
            lables.add(crackcar.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner4.setAdapter(spinnerAdapter);



    }

    //GetCar: Trae la informacion de la base de datos de carreras y lo inserta en el spinner.
    private class GetCar extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarcarrera.php?Nombre_facultad="+Facultad+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("carr");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_carrera"),
                                    catObj.getString("nombre_carrera"));
                            crackcar.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }

    private void populateSpinner3() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackgen.size(); i++) {
            lables.add(crackgen.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner2.setAdapter(spinnerAdapter);



    }

    //GetCar: Trae la informacion de la base de datos de carreras y lo inserta en el spinner.
    private class GetGen extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listargen.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray genero = jsonObj
                                .getJSONArray("gen");

                        for (int i = 0; i < genero.length(); i++) {
                            JSONObject catObj = (JSONObject) genero.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_genero"),
                                    catObj.getString("sexo"));
                            crackgen.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner3();
        }
    }

    private void populateSpinner4() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < cracktu.size(); i++) {
            lables.add(cracktu.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner5.setAdapter(spinnerAdapter);



    }

    //GetCar: Trae la informacion de la base de datos de carreras y lo inserta en el spinner.
    private class GetTu extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listartu.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray tiu = jsonObj
                                .getJSONArray("tu");

                        for (int i = 0; i < tiu.length(); i++) {
                            JSONObject catObj = (JSONObject) tiu.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_tipou"),
                                    catObj.getString("tipo"));
                            cracktu.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner4();
        }
    }

    private void populateSpinner5() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackest.size(); i++) {
            lables.add(crackest.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner3.setAdapter(spinnerAdapter);



    }

    //GetCar: Trae la informacion de la base de datos de carreras y lo inserta en el spinner.
    private class GetEst extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarest.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray genero = jsonObj
                                .getJSONArray("est");

                        for (int i = 0; i < genero.length(); i++) {
                            JSONObject catObj = (JSONObject) genero.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_estadou"),
                                    catObj.getString("estado"));
                            crackest.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner5();
        }
    }
}


