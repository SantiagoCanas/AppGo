package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class VerLFragment extends Fragment {

    ListView listViewLista;
    Button Buscarl, Cancelar;
    Spinner spinnerl2;
    String TipoP, Search;
    EditText IdU, Fec;

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";


    private String mParam1;
    private String mParam2;

    public VerLFragment() {
        // Required empty public constructor
    }


    public static VerLFragment newInstance(String param1, String param2) {
        VerLFragment fragment = new VerLFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    //onCreateView: Este metodo se caracteriza traer los datos requeridos segun los requerimientos que exige el usuario.
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_ver_l, container, false);
        Fec=(EditText)view.findViewById(R.id.TextFec);
        IdU=(EditText)view.findViewById(R.id.TextIdl);
        spinnerl2 = (Spinner) view.findViewById(R.id.spinnerL2);
        listViewLista = (ListView) view.findViewById(R.id.listViewL);
        Buscarl = view.findViewById(R.id.ButtonOkL);
        Buscarl.setEnabled(false);
        Buscarl.setVisibility(View.INVISIBLE);
        IdU.setEnabled(false);
        IdU.setVisibility(View.INVISIBLE);
        Fec.setEnabled(false);
        Fec.setVisibility(View.GONE);
        Cancelar = view.findViewById(R.id.buttonCancelarL);
        cancelar();
        Fec.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.TextFec:
                        showDatePickerDialog();
                        break;
            }
        }});












        String[] Busqueda = {"Seleccione Tipo Busqueda","Buscar Todo","Total Objetos Prestados","Total Solicitantes","Buscar por ID Usuario", "Objetos Prestados por ID Usuario", "Buscar por Fecha","Objetos Prestados por Fecha","Total Solicitantes por Fecha"};
        spinnerl2.setAdapter(new ArrayAdapter<String>(getActivity().getApplicationContext(), R.layout.textview_spinner, Busqueda));
        spinnerl2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                Search = spinnerl2.getItemAtPosition(position).toString();
                if (Search.equals("Buscar Todo")) {
                    downloadJSON("http://192.168.0.26/beta/visualizar_solicitudt.php");
                    Buscarl.setEnabled(false);
                    Buscarl.setVisibility(View.INVISIBLE);
                    IdU.setEnabled(false);
                    IdU.setVisibility(View.INVISIBLE);
                    Fec.setEnabled(false);
                    Fec.setVisibility(View.INVISIBLE);
                }
                else if (Search.equals("Total Objetos Prestados")) {
                    downloadJSON2("http://192.168.0.26/beta/visualizar_solicitudtc.php");
                    Buscarl.setEnabled(false);
                    Buscarl.setVisibility(View.INVISIBLE);
                    IdU.setEnabled(false);
                    IdU.setVisibility(View.INVISIBLE);
                    Fec.setEnabled(false);
                    Fec.setVisibility(View.INVISIBLE);
                }
                else if (Search.equals("Total Solicitantes")) {
                    downloadJSON3("http://192.168.0.26/beta/visualizar_solicitudtf.php");
                    Buscarl.setEnabled(false);
                    Buscarl.setVisibility(View.INVISIBLE);
                    IdU.setEnabled(false);
                    IdU.setVisibility(View.INVISIBLE);
                    Fec.setEnabled(false);
                    Fec.setVisibility(View.INVISIBLE);
                }
                else if (Search.equals("Buscar por ID Usuario")) {
                    Buscarl.setEnabled(true);
                    Buscarl.setVisibility(View.VISIBLE);
                    IdU.setEnabled(true);
                    IdU.setVisibility(View.VISIBLE);
                    Fec.setEnabled(false);
                    Fec.setVisibility(View.INVISIBLE);
                    listViewLista.setAdapter(null);
                    Buscarl.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            downloadJSON("http://192.168.0.26/beta/visualizar_solicitud.php?Id_usuario=" + IdU.getText().toString() + "");

                        }
                    });
                }
                else if (Search.equals("Objetos Prestados por ID Usuario")) {
                    Buscarl.setEnabled(true);
                    Buscarl.setVisibility(View.VISIBLE);
                    IdU.setEnabled(true);
                    IdU.setVisibility(View.VISIBLE);
                    Fec.setEnabled(false);
                    Fec.setVisibility(View.INVISIBLE);
                    listViewLista.setAdapter(null);
                    Buscarl.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            downloadJSON2("http://192.168.0.26/beta/visualizar_solicitud2.php?Id_usuario=" + IdU.getText().toString() + "");

                        }
                    });
                }

                   else if (Search.equals("Buscar por Fecha")) {
                    Buscarl.setEnabled(true);
                    Buscarl.setVisibility(View.VISIBLE);
                    IdU.setEnabled(false);
                    IdU.setVisibility(View.INVISIBLE);
                    Fec.setEnabled(true);
                    Fec.setVisibility(View.VISIBLE);
                    listViewLista.setAdapter(null);
                    Buscarl.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            downloadJSON("http://192.168.0.26/beta/visualizar_solicitudfecha.php?Fecha_solicitud=" +Fec.getText().toString()+ "");

                        }
                    });
                }

                else if (Search.equals("Objetos Prestados por Fecha")) {
                    Buscarl.setEnabled(true);
                    Buscarl.setVisibility(View.VISIBLE);
                    IdU.setEnabled(false);
                    IdU.setVisibility(View.INVISIBLE);
                    Fec.setEnabled(true);
                    Fec.setVisibility(View.VISIBLE);
                    listViewLista.setAdapter(null);
                    Buscarl.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            downloadJSON2("http://192.168.0.26/beta/visualizar_solicitudfecha2.php?Fecha_solicitud=" +Fec.getText().toString()+ "");

                        }
                    });
                }
                else if (Search.equals("Total Solicitantes por Fecha")) {
                    Buscarl.setEnabled(true);
                    Buscarl.setVisibility(View.VISIBLE);
                    IdU.setEnabled(false);
                    IdU.setVisibility(View.INVISIBLE);
                    Fec.setEnabled(true);
                    Fec.setVisibility(View.VISIBLE);
                    listViewLista.setAdapter(null);
                    Buscarl.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            downloadJSON3("http://192.168.0.26/beta/visualizar_solicitudfecha3.php?Fecha_solicitud=" +Fec.getText().toString()+ "");

                        }
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });
        return view;
    }


    //downloadJSON: Trae los datos de la base de datos en formano JSON y lo adapta a java.
    private void downloadJSON(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                try {
                    loadIntoListView(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView: Carga los datos de la base de datos en la lista.
//showDatePickerDialog: Abre el calendario par visualizar por fecha
    private void loadIntoListView(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Id_solicitud: " +obj.getString("id_solicitud") + System.lineSeparator() + " Fecha de Solicitud Realizada: " + obj.getString("fecha_solicitud") + System.lineSeparator() + " Id_usuario: " + obj.getString("id_usuario") + System.lineSeparator()  + " Nombre Usuario: " + obj.getString("nombre_usuario") + System.lineSeparator()  + " Id_objeto: " + obj.getString("id_objeto") + System.lineSeparator() + " Nombre Objeto Solicitado: " + obj.getString("nombre_objeto") + System.lineSeparator() + " Cantidad: " + obj.getString("cantidad") + System.lineSeparator() + " Id_sede: " + obj.getString("id_sede") + System.lineSeparator() + " Nombre_sede: " + obj.getString("nombre_sede") + System.lineSeparator() + " Id_aula: " + obj.getString("id_aula") + System.lineSeparator() + " Ubicacion_aula: " + obj.getString("ubicacion_aula")+ System.lineSeparator() + " Fecha Devolución: " + obj.getString("fecha_devolucion");
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(), android.R.layout.simple_list_item_1, stocks);
        listViewLista.setAdapter(arrayAdapter);
    }


    //downloadJSON: Trae los datos de la base de datos en formano JSON y lo adapta a java.
    private void downloadJSON2(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                try {
                    loadIntoListView2(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView: Carga los datos de la base de datos en la lista.
//showDatePickerDialog: Abre el calendario par visualizar por fecha
    private void loadIntoListView2(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Objeto: " +obj.getString("nombre_objeto") + System.lineSeparator() + " Cantidad Prestada: " + obj.getString("Total");
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(), android.R.layout.simple_list_item_1, stocks);
        listViewLista.setAdapter(arrayAdapter);
    }
    //downloadJSON: Trae los datos de la base de datos en formano JSON y lo adapta a java.
    private void downloadJSON3(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                try {
                    loadIntoListView3(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView: Carga los datos de la base de datos en la lista.
//showDatePickerDialog: Abre el calendario par visualizar por fecha
    private void loadIntoListView3(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Facultad: " +obj.getString("nombre_facultad") + System.lineSeparator() + " Cantidad Solicitantes: " + obj.getString("Total");
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity().getApplicationContext(), android.R.layout.simple_list_item_1, stocks);
        listViewLista.setAdapter(arrayAdapter);
    }

    private void showDatePickerDialog() {
        Fecha newFragment = Fecha.newInstance(new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                // +1 because January is zero
                final String selectedDate = year + "-" + (month+1) + "-" + day;
                Fec.setText(selectedDate);
            }
        });

        newFragment.show(getActivity().getSupportFragmentManager(), "datePicker");
    }
    public void cancelar(){
        final Context context = getActivity().getApplicationContext();
        Cancelar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, MenuFrag3.class);
                startActivity(menu);

            }

        });
    }
}