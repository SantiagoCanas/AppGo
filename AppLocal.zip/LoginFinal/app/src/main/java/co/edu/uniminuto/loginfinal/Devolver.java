package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.android.volley.RequestQueue;



public class Devolver extends AppCompatActivity {
    final private int REQUEST_CODE_ASK_PERMISSION=111;
    Button Atras;
    public static RequestQueue requestQueue;
    public static TextView ResultadoD;
    public static Button scan_btn;
    @Override
    //onCreate: Redirige a la clase DevolverQR.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.escaner2);
        cancelar();
        ResultadoD = (TextView) findViewById(R.id.result_textd);
        scan_btn = (Button) findViewById(R.id.btn_scand);
        solicitarPermisos();
        scan_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(getApplicationContext(), DevolverQR.class));

            }
        });
    }
    //solicitarPermisos: Solicita permisos al usuario.
    private void solicitarPermisos() {
        //int permisoStorage = ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE);
        int permisoCamara = ActivityCompat.checkSelfPermission(Devolver.this, Manifest.permission.CAMERA);

        if (permisoCamara!= PackageManager.PERMISSION_GRANTED)
            if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.CAMERA}, REQUEST_CODE_ASK_PERMISSION);
            }
    }

    //cancelar:  Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Atras = findViewById(R.id.ButtonAtrasEs2);
        Atras.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, MenuFrag3.class);
                startActivity(menu);

            }

        });
    }
}
