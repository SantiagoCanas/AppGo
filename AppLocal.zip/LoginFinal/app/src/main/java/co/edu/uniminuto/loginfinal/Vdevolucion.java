package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;


public class Vdevolucion extends AppCompatActivity {
    ListView listView2;
    Button Atras;
    @Override
    //onCreate: Este metodo se caracteriza traer los datos requeridos segun el id al momento de iniciar sesion.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verdevolucion);
        cancelar();
        listView2 = (ListView) findViewById(R.id.listViewD);
        downloadJSON("http://192.168.0.26/beta/visualizar_devolucion.php?Id_usuario="+SesionFragment.Usuarios+"");
    }

    //downloadJSON: Trae los datos de la base de datos en formano JSON y lo adapta a java.
    private void downloadJSON(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                //Toast.makeText(getApplicationContext(), s, Toast.LENGTH_SHORT).show();
                try {
                    loadIntoListView(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView: Carga los datos de la base de datos en la lista.
//showDatePickerDialog: Abre el calendario par visualizar por fecha
    private void loadIntoListView(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Id_solicitud: " +obj.getString("id_solicitud") + System.lineSeparator() + " Fecha Devolución: " + obj.getString("fecha_devolucion") + System.lineSeparator() + " Id_usuario: " + obj.getString("id_usuario") + System.lineSeparator()  + " Nombre Usuario: " + obj.getString("nombre_usuario") + System.lineSeparator()  + " Id_objeto: " + obj.getString("id_objeto") + System.lineSeparator() + " Nombre Objeto Solicitado: " + obj.getString("nombre_objeto") + System.lineSeparator() + " Cantidad: " + obj.getString("cantidad") + System.lineSeparator() + " Id_sede: " + obj.getString("id_sede") + System.lineSeparator() + " Nombre_sede: " + obj.getString("nombre_sede") + System.lineSeparator() + " Id_aula: " + obj.getString("id_aula") + System.lineSeparator() + " Ubicacion_aula: " + obj.getString("ubicacion_aula");
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView2.setAdapter(arrayAdapter);
    }


    //cancelar: Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Atras = findViewById(R.id.ButtonAtrasD);
        Atras.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent menu = new Intent(context, MenuFrag3.class);
                startActivity(menu);

            }

        });
    }
}
