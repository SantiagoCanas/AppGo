package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class VisualizarU extends AppCompatActivity {
    ListView listView2;
    Button Atras;
    Spinner spinner2,spinner3,spinner4;
    String Facultad, Carrera, Espec;
    private ArrayList<Usuarios> crackfac;
    private ArrayList<Usuarios> crackcar;
    @Override
    //onCreate: Este metodo se caracteriza por definir las variables para visualizar objetos.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.verusuario);
        cancelar();
        listView2 = (ListView) findViewById(R.id.listView);
        spinner2 = (Spinner) findViewById(R.id.spinnerVu2);
        spinner3 = (Spinner) findViewById(R.id.spinnerVu3);
        spinner2.setEnabled(false);
        spinner2.setVisibility(View.GONE);
        spinner3.setEnabled(false);
        spinner3.setVisibility(View.GONE);
        spinner4 = (Spinner) findViewById(R.id.spinnerVu4);
        String[] Busc = {"Seleccione tipo Busqueda", "Usuarios Detallados","Cantidad Usuarios Facultad","Cantidad Usuarios Carrera", "Cantidad Usuarios Carrera Especifica","Cantidad Usuarios por Sexo"};
        spinner4.setAdapter(new ArrayAdapter<String>(this, R.layout.textview_spinner, Busc));
        spinner4.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   limpiar();
                Espec = spinner4.getItemAtPosition(position).toString();

                new VisualizarU.GetFacul().execute();
                crackfac.clear();
                crackcar.clear();
                switch (Espec) {
                    case "Usuarios Detallados":
                        crackfac.clear();
                        crackcar.clear();
                        spinner2.setEnabled(false);
                        spinner2.setVisibility(View.GONE);
                        spinner3.setEnabled(false);
                        spinner3.setVisibility(View.GONE);
                        downloadJSON3("http://192.168.0.26/beta/visualizar_usuariodet.php");
                        break;
                    case "Cantidad Usuarios Facultad":
                        crackfac.clear();
                        crackcar.clear();
                        spinner2.setEnabled(false);
                        spinner2.setVisibility(View.GONE);
                        spinner3.setEnabled(false);
                        spinner3.setVisibility(View.GONE);
                        downloadJSON4("http://192.168.0.26/beta/visualizar_faces.php");
                        break;
                    case "Cantidad Usuarios Carrera":
                        crackfac.clear();
                        crackcar.clear();
                        spinner2.setEnabled(true);
                        spinner2.setVisibility(View.VISIBLE);
                        spinner3.setEnabled(false);
                        spinner3.setVisibility(View.GONE);
                        String temp3 = "http://192.168.0.26/beta/visualizar_usuariocar.php?Nombre_facultad="+Facultad+ "";
                        temp3 = temp3.replaceAll(" ", "%20");
                        downloadJSON5(temp3);
                        break;
                    case "Cantidad Usuarios Carrera Especifica":
                        crackfac.clear();
                        crackcar.clear();
                        spinner2.setEnabled(true);
                        spinner2.setVisibility(View.VISIBLE);
                        spinner3.setEnabled(true);
                        spinner3.setVisibility(View.VISIBLE);
                        String temp4 = "http://192.168.0.26/beta/visualizar_car.php?Nombre_facultad="+Facultad+"&Nombre_carrera="+Carrera+ "";
                        temp4 = temp4.replaceAll(" ", "%20");
                        downloadJSON8(temp4);
                        break;
                    case "Cantidad Usuarios por Sexo":
                        crackfac.clear();
                        crackcar.clear();
                        spinner2.setEnabled(true);
                        spinner2.setVisibility(View.VISIBLE);
                        spinner3.setEnabled(false);
                        spinner3.setVisibility(View.GONE);
                        String temp5= "http://192.168.0.26/beta/visualizar_usuariogen.php?Nombre_facultad="+Facultad+ "";
                        temp5 = temp5.replaceAll(" ", "%20");
                        downloadJSON6(temp5);
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });








        crackfac = new ArrayList<Usuarios>();
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {
                crackfac.clear();
                crackcar.clear();
                Facultad = spinner2.getItemAtPosition(position).toString();
                new VisualizarU.GetCar().execute();
                if (Espec=="Usuarios Detallados") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(false);
                    spinner2.setVisibility(View.GONE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    downloadJSON3("http://192.168.0.26/beta/visualizar_usuariodet.php");
                }
                if (Espec=="Cantidad Usuarios Facultad") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(false);
                    spinner2.setVisibility(View.GONE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    downloadJSON4("http://192.168.0.26/beta/visualizar_faces.php");
                }
                if (Espec=="Cantidad Usuarios Carrera") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(true);
                    spinner2.setVisibility(View.VISIBLE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    String temp3 = "http://192.168.0.26/beta/visualizar_usuariocar.php?Nombre_facultad=" + Facultad + "";
                    temp3 = temp3.replaceAll(" ", "%20");
                    downloadJSON5(temp3);
                }
                if (Espec=="Cantidad Usuarios Carrera Especifica") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(true);
                    spinner2.setVisibility(View.VISIBLE);
                    spinner3.setEnabled(true);
                    spinner3.setVisibility(View.VISIBLE);
                    String temp4 = "http://192.168.0.26/beta/visualizar_car.php?Nombre_facultad=" + Facultad + "&Nombre_carrera=" + Carrera + "";
                    temp4 = temp4.replaceAll(" ", "%20");
                    downloadJSON8(temp4);
                }
                if (Espec=="Cantidad Usuarios por Sexo") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(true);
                    spinner2.setVisibility(View.VISIBLE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    String temp5 = "http://192.168.0.26/beta/visualizar_usuariogen.php?Nombre_facultad=" + Facultad + "";
                    temp5 = temp5.replaceAll(" ", "%20");
                    downloadJSON6(temp5);
                }



            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });

        crackcar = new ArrayList<Usuarios>();
        spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {


            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id)
            {   crackfac.clear();
                crackcar.clear();
                Carrera = spinner3.getItemAtPosition(position).toString();
                if (Espec=="Usuarios Detallados") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(false);
                    spinner2.setVisibility(View.GONE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    downloadJSON3("http://192.168.0.26/beta/visualizar_usuariodet.php");
                }
                if (Espec=="Cantidad Usuarios Facultad") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(false);
                    spinner2.setVisibility(View.GONE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    downloadJSON4("http://192.168.0.26/beta/visualizar_faces.php");
                }
                if (Espec=="Cantidad Usuarios Carrera") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(true);
                    spinner2.setVisibility(View.VISIBLE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    String temp3 = "http://192.168.0.26/beta/visualizar_usuariocar.php?Nombre_facultad=" + Facultad + "";
                    temp3 = temp3.replaceAll(" ", "%20");
                    downloadJSON5(temp3);
                }
                if (Espec=="Cantidad Usuarios Carrera Especifica") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(true);
                    spinner2.setVisibility(View.VISIBLE);
                    spinner3.setEnabled(true);
                    spinner3.setVisibility(View.VISIBLE);
                    String temp4 = "http://192.168.0.26/beta/visualizar_car.php?Nombre_facultad=" + Facultad + "&Nombre_carrera=" + Carrera + "";
                    temp4 = temp4.replaceAll(" ", "%20");
                    downloadJSON8(temp4);
                }
                if (Espec=="Cantidad Usuarios por Sexo") {
                    crackfac.clear();
                    crackcar.clear();
                    spinner2.setEnabled(true);
                    spinner2.setVisibility(View.VISIBLE);
                    spinner3.setEnabled(false);
                    spinner3.setVisibility(View.GONE);
                    String temp5 = "http://192.168.0.26/beta/visualizar_usuariogen.php?Nombre_facultad=" + Facultad + "";
                    temp5 = temp5.replaceAll(" ", "%20");
                    downloadJSON6(temp5);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {
                // vacio

            }
        });



    }

    //downloadJSON3: Trae los datos de la base de datos de usuarios detallados en formato JSON y lo adapta a java.
       private void downloadJSON3(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    loadIntoListView3(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView3: Carga los datos usuarios detallados de la base de datos en la lista.
    private void loadIntoListView3(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);

            stocks[i] = System.lineSeparator() + (" Facultad: ") +obj.getString("nombre_facultad") + System.lineSeparator() + " Carrera: " + obj.getString("nombre_carrera") + System.lineSeparator() + " ID Usuario: " + obj.getString("id_usuario") + System.lineSeparator() + " Nombre de Usuario: " + obj.getString("nombre_usuario") + System.lineSeparator()  + " Telefono: " + obj.getString("telefono") + System.lineSeparator()  + " Genero: " + obj.getString("sexo") + System.lineSeparator()+ " Correo: " + obj.getString("correo") + System.lineSeparator()+ " Estado: " + obj.getString("estado");
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView2.setAdapter(arrayAdapter);
    }



    //downloadJSON4: Trae los datos de la base de datos cantidad de usuarios de facultad en formato JSON y lo adapta a java.
    private void downloadJSON4(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    loadIntoListView4(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView4: Carga los datos cantidad de usuarios de facultad de la base de datos en la lista.
    private void loadIntoListView4(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator()+" Facultad: " +obj.getString("nombre_facultad") + System.lineSeparator() + " Integrantes: " + obj.getString("integrantes");
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView2.setAdapter(arrayAdapter);
    }


    //downloadJSON5: Trae los datos de la base de datos de usuarios de carrera en formato JSON y lo adapta a java.
    private void downloadJSON5(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    loadIntoListView5(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView5: Carga los datos cantidad de usuarios de carrera de la base de datos en la lista.
    private void loadIntoListView5(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Facultad: " +obj.getString("nombre_facultad") + System.lineSeparator() + " Carrera: " + obj.getString("nombre_carrera") + System.lineSeparator() + "Integrantes: " + obj.getString("integrantes") ;
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView2.setAdapter(arrayAdapter);
    }


    //downloadJSON6: Trae los datos de la base de datos de usuarios de carrera especifica en formato JSON y lo adapta a java.
    private void downloadJSON6(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    loadIntoListView6(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView6: Carga los datos cantidad de usuarios de carrera especifica de la base de datos en la lista.
    private void loadIntoListView6(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Facultad: " +obj.getString("nombre_facultad") + System.lineSeparator() + " Carrera: " + obj.getString("nombre_carrera") + System.lineSeparator() + " Genero: " + obj.getString("sexo") + System.lineSeparator()  + " Integrantes: " + obj.getString("integrantes") ;
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView2.setAdapter(arrayAdapter);
    }


    //downloadJSON7: Trae los datos de la base de datos de cantidad de usuarios por sexo den formato JSON y lo adapta a java.
    private void downloadJSON7(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    loadIntoListView7(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView7: Carga los datos cantidad de usuarios por sexo de la base de datos en la lista.
    private void loadIntoListView7(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = System.lineSeparator() +" Nombre: " +obj.getString("nombre_usuario") + System.lineSeparator() + " Genero: " + obj.getString("sexo") ;
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView2.setAdapter(arrayAdapter);
    }

    //downloadJSON8: Trae los datos de la base de datos de cantidad de gestores en formato JSON y lo adapta a java.
    private void downloadJSON8(final String urlWebService) {

        class DownloadJSON extends AsyncTask<Void, Void, String> {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }


            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);

                try {
                    loadIntoListView8(s);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(urlWebService);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }
        DownloadJSON getJSON = new DownloadJSON();
        getJSON.execute();
    }

    //loadIntoListView8: Carga los datos cantidad de gestores de la base de datos en la lista.
    private void loadIntoListView8(String json) throws JSONException {
        JSONArray jsonArray = new JSONArray(json);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);

            stocks[i] = System.lineSeparator() +" Usuario: " +obj.getString("tipo") + System.lineSeparator() + " Genero: " + obj.getString("sexo") + System.lineSeparator() + " Integrantes: " + obj.getString("integrantes") ;
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, stocks);
        listView2.setAdapter(arrayAdapter);
    }



    //cancelar:  Devuelve a la activity anterior, cancela el proceso.
    public void cancelar(){
        final Context context = this;
        Atras = findViewById(R.id.ButtonAtrasVu);
        Atras.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                onBackPressed();

            }

        });
    }




    //populateSpinner: Rellena el spinner con la informacion requerida.
    private void populateSpinner() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackfac.size(); i++) {
            lables.add(crackfac.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner2.setAdapter(spinnerAdapter);



    }


    //GetFacul: Trae la informacion de la base de datos de facultades y lo inserta en el spinner.
    private class GetFacul extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarfacu.php";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("facul");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_facultad"),
                                    catObj.getString("nombre_facultad"));
                            crackfac.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner();
        }
    }

    //populateSpinner2: Rellena el spinner con la informacion requerida.
    private void populateSpinner2() {
        List<String> lables = new ArrayList<String>();


        for (int i = 0; i < crackcar.size(); i++) {
            lables.add(crackcar.get(i).getName());
        }


        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(getApplicationContext(),
                android.R.layout.simple_spinner_item, lables);


        spinnerAdapter
                .setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);


        spinner3.setAdapter(spinnerAdapter);



    }


    //GetCar: Trae la informacion de la base de datos de carrera y lo inserta en el spinner.
    private class GetCar extends AsyncTask<Void, Void, Void> {

        @Override

        protected Void doInBackground(Void... arg0) {
            ServiceHandler jsonParser = new ServiceHandler();
            String temp = "http://192.168.0.26/beta/listarcar.php?Nombre_facultad="+Facultad+"";

            temp = temp.replaceAll(" ", "%20");
            String json = jsonParser.makeServiceCall(temp, ServiceHandler.GET);

            Log.e("Response: ", "> " + json);

            if (json != null) {
                try {
                    JSONObject jsonObj = new JSONObject(json);
                    if (jsonObj != null) {
                        JSONArray categoria = jsonObj
                                .getJSONArray("car");

                        for (int i = 0; i < categoria.length(); i++) {
                            JSONObject catObj = (JSONObject) categoria.get(i);
                            Usuarios cat = new Usuarios(catObj.getInt("id_carrera"),
                                    catObj.getString("nombre_carrera"));
                            crackcar.add(cat);
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } else {
                Log.e("JSON Data", "¿No ha recibido ningún dato desde el servidor!");
            }

            return null;
        }
        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            populateSpinner2();
        }
    }

    public void limpiar() {
        listView2.setAdapter(null);
    }

}
