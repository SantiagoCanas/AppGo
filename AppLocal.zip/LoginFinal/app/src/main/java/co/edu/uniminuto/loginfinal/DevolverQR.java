package co.edu.uniminuto.loginfinal;

//Importación de Librerias
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.zxing.Result;

import me.dm7.barcodescanner.zxing.ZXingScannerView;

public class DevolverQR extends AppCompatActivity implements ZXingScannerView.ResultHandler {

    ZXingScannerView ScannerView;
    @Override
    //onCreate: Llama a la libreria para escaner y la guarda en una variable.
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScannerView = new ZXingScannerView(this);
        setContentView(ScannerView);

    }

    @Override
    //handleResult: Trae ek resultado.
    public void handleResult(Result result) {

        Devolver.ResultadoD.setText(result.getText());
        onBackPressed();
    }


    @Override
    //onPause: Detiene la camara.
    protected void onPause() {
        super.onPause();

        ScannerView.stopCamera();
    }

    @Override
    //onResume: Reanuda la camara.
    protected void onResume() {
        super.onResume();

        ScannerView.setResultHandler(this);
        ScannerView.startCamera();
    }


}